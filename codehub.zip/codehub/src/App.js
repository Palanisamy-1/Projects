import React from 'react'
import {BrowserRouter , Routes , Route} from "react-router-dom"
import Login from './pages/Login'
import './App.css'
import Home from './pages/Home'
import Htmll from './pages/Htmll'
import Pagecss from './pages/Pagecss'
import Pagejava from './pages/Pagejava'
import Pagereact from './pages/Pagereact'


const App = () => {
  return (
    <div>
     <BrowserRouter>
     <Routes>
     <Route path='/' element={<Login/>}></Route>
     <Route path='/home' element={<Home/>}/>
     <Route path='/html' element={<Htmll/>}/>
     <Route path='/css' element={<Pagecss/>}/>
     <Route path='/java' element={<Pagejava/>}/>
     <Route path='/react' element={<Pagereact/>}/>
  
     </Routes>
     </BrowserRouter>
    </div>
  )
}

export default App