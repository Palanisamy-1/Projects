import React from 'react'
import {Link } from 'react-router-dom'
import './pages.css'

const Pagecss = () => {
  const htmlCode = `
      `;
  const htmlexp = `
`;
  return (
    <div className='pagecss'>
    <div className='nav'>
    <div className='h3'>
    <h3>Codehub</h3>
    </div>
    <div  className='name'>
    <button id="bb" >Sampleuser</button>
    </div>
    </div>
    <div className='nav2'>
   
    <li><Link to='/html' style={{ color: 'white' , textDecoration: 'none' }}>
    HTML
    </Link>
    </li>
   
    <li><Link to='/java' style={{ color: 'white' , textDecoration: 'none' }}>
    Java Script
    </Link>
    </li>
    <li><Link to='/react' style={{ color: 'white' , textDecoration: 'none' }}>
    React.js
    </Link>
    </li>
    <li><Link to='/home'     style={{ color: 'white' , textDecoration: 'none' }}>
    Home
    </Link>
    </li>
     </div>
     <div className='htmlarea'>
     <h1>Welcome to 'CSS' Learning!</h1>
     <div className='def'>
     <p>CSS stands for Cascading Style Sheets. It's a style sheet language used for describing the presentation and formatting of a document written in a markup language like HTML. CSS allows web developers to control the layout, appearance, and design of web pages. By separating the content of a webpage from its presentation,
      </p><p>CSS enables greater flexibility and consistency in website design across different devices and screen sizes.</p>
      </div>
      <div className='syntax'>
      <h3>A simple CSS Program:</h3>
      <div className='eg'>
      <pre>{htmlCode}</pre>
      </div>
      </div>
      <div className='exp'>
      <pre>{htmlexp}</pre></div>
     </div>
    </div>
  )
}

export default Pagecss