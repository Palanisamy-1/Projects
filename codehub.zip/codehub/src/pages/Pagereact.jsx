import React from 'react'
import {Link } from 'react-router-dom'
import './pages.css'

const Pagereact = () => {
  const htmlCode = `
    <!DOCTYPE html>
    <html>
    <head>
      <title>My HTML Example</title>
    </head>
    <body>
      <h1>Hello, World!</h1>
      <p>This is a sample HTML code.</p>
    </body>
    </html>
  `;
  const htmlexp = `

  1. <!DOCTYPE html>:
     - This is a document type declaration. It specifies that the document is an HTML5 document. It tells the web browser which version of HTML the document is using.
  
  2. <html>:
     - This tag represents the root element of an HTML document. Everything inside an HTML document is enclosed within the <html> tags.
  
  3. <head>:
     - The <head> element contains meta-information about the HTML document, such as the document's title, links to stylesheets, scripts, and other meta tags.
     - In your example, the <head> section contains only one tag, <title>, which sets the title of the HTML document to "My HTML Example".
  
  4. <body>:
     - The <body> element contains the content of the HTML document that is visible to users.
     - Inside the <body> element, there are two tags:
       - <h1>: This is a heading element that displays text in a large, bold font. In your example, it contains the text Hello, World!.
       - <p>: This is a paragraph element that represents a block of text. In your example, it contains the text This is a sample HTML code.
  `;
  return (
    <div className='pagereact'>
    <div className='nav'>
    <div className='h3'>
    <h3>Codehub</h3>
    </div>
    <div  className='name'>
    <button id="bb" >Sampleuser</button>
    </div>
    </div>
    <div className='nav2'>
   
    <li><Link to='/html' style={{ color: 'white' , textDecoration: 'none' }}>
    HTML
    </Link>
    </li>
    <li><Link to='/css' style={{ color: 'white' , textDecoration: 'none' }}>
    CSS
    </Link>
    </li>
    <li><Link to='/java' style={{ color: 'white' , textDecoration: 'none' }}>
    Java Script
    </Link>
    </li>
    <li><Link to='/home'     style={{ color: 'white' , textDecoration: 'none' }}>
    Home
    </Link>
    </li>
     </div>
     <div className='htmlarea'>
     <h1>Welcome to 'Reactjs' Learning!</h1>
     <div className='def'>
     <p>HyperText Markup Language or HTML is the standard markup language for documents designed to be displayed in a web browser.
     </p><p>It defines the content and structure of web content.
      It is often assisted by technologies such as Cascading Style Sheets (CSS) and scripting languages such as JavaScript.</p>
      <p>HTML is the standard markup language for Web pages.
      
      With HTML you can create your own Website.
      
      HTML is easy to learn - You will enjoy it!</p>
      </div>
      <div className='syntax'>
      <h3>A simple HTML Program:</h3>
      <div className='eg'>
      <pre>{htmlCode}</pre>
      </div>
      </div>
      <div className='exp'>
      <pre>{htmlexp}</pre></div>
     </div>
    </div>
  )
}

export default Pagereact