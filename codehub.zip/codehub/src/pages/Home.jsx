import React from 'react'
import './pages.css'
import {Link } from 'react-router-dom'

const Home = () => {
 
  return (
    <div className='home'>
    <div className='nav'>
    <div className='h3'>
    <h3>Codehub</h3>
    </div>
    <div  className='name'>
    <button id="bb" >Sampleuser</button>
    </div>
    </div>
    <div className='nav2'>
   
    <li><Link to='/html' style={{ color: 'white' , textDecoration: 'none' }}>
    HTML
    </Link>
    </li>
    <li><Link to='/css' style={{ color: 'white' , textDecoration: 'none' }}>
    CSS
    </Link>
    </li>
    <li><Link to='/java'style={{ color: 'white' , textDecoration: 'none' }}>
    Java Script
    </Link>
    </li>
    <li><Link to='/react' style={{ color: 'white' , textDecoration: 'none' }}>
    React.js
    </Link>
    </li>
     </div>
     <div className='area'>
     <div className='h1'>
     <h1>Learn to Code,<br></br>With Codehub!</h1>
     </div>
     <div className='para'>
     <p>Welcome to Code Hub, your ultimate destination for all things coding and
     programming! Whether you're a seasoned developer looking to enhance your skills 
     or a beginner eager to dive into the world of coding, Code Hub is here to
     empower you on your journey. Explore our comprehensive resources, engaging tutorials,
     and vibrant community to unlock the full potential of your coding prowess.
     Join us at CodeHub 
     and let's embark on a transformative coding experience together!</p>
     </div>
     <div className='search'>
     <input type='text' id='input' placeholder='Search eg: HTML'></input>
     </div>
     </div>
    
    </div>
  )
}

export default Home