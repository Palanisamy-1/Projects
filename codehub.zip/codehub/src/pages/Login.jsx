import React from 'react'
import {Link, Outlet } from 'react-router-dom'
import './pages.css'

const Login = () => {
  return (
    <div className='Maggy'> 
    <Outlet/>
    <form className="imform">
    <h1>LOGIN</h1>
            <div className="donkey"><label>
                User Name:
            </label><br/>
                <input type="text" name="username"  required/>
            </div>
  
            <div className="donkey"><label>
                Email:
                </label>
                <br/>
                <input type="email"  name="email" required/>
            </div>
            <div className="donkey" >
            <label>
                Password:
            </label><br/>
                <input type="password" required/>
            </div>

            <div className="donkey">
            <Link to='/home'>
            <input className="submit" type="submit"/>
            </Link>
            </div>
        </form>
       
    </div>
  )
}

export default Login